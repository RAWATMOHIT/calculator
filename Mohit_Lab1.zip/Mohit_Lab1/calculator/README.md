Calculator.js: a node.js Application (MAD6123 Lab Test 1)
==============================================
A simple node.js calculator app to perform the basic operation with all the necessary validation

#Student_Name: Mohit Rawat
#MAD6123 Lab Test 1

To build, simply:

1. Runs `npm install` to install dependencies.
2. Runs `npm start` to run Mocha and execute the unit tests.

